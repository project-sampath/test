#!/bin/bash
$JBOSS_HOME/bin/standalone.sh -b 0.0.0.0 --server-config=standalone-full.xml
